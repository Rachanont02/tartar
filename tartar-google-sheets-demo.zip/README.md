# TarTar — Google Sheets Demo
ตัวอย่างพร้อมทดสอบ: ปุ่มเพิ่ม 1 รายการ และปุ่มโหลดรายการจาก Google Sheets (Apps Script)

## ตั้งค่า
1) ทำ Apps Script Web App (GET list, POST add) แล้ว Deploy เป็น Web App
2) เอา URL `/exec` มาใส่ใน `api.js` เป็น `API_BASE`
3) ตั้ง `API_TOKEN` ให้ตรงกับ Script ของคุณ

## ทดสอบ
- เปิดเว็บ → กด "เพิ่มตัวอย่าง 1 รายการ"
- กด "โหลดรายการ Trips" เพื่อดูผล
