export const API_BASE = 'https://script.google.com/macros/s/PASTE_YOUR_EXEC_URL_HERE/exec'; // TODO
export const API_TOKEN = 'CHANGE_ME_TARTAR_TOKEN'; // TODO

export async function listTrips() {
  const url = `${API_BASE}?action=list&token=${encodeURIComponent(API_TOKEN)}`;
  const res = await fetch(url, { cache: 'no-store' });
  const json = await res.json();
  if (!json.ok) throw new Error(json.error || 'API error');
  return json.data.rows || [];
}

export async function addTrip(row) {
  const res = await fetch(API_BASE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'add', token: API_TOKEN, row })
  });
  const json = await res.json();
  if (!json.ok) throw new Error(json.error || 'API error');
  return json.data.id;
}
